# t2-segsis

## Integrantes
- Giovane Milani
- Vinicius Boff

## Requisitos
- Python 3.10

```
pip install pycryptodome
```

## Execução (Windows)
No terminal, execute:

```py
py ./etapa1.py
# ou
py ./etapa2.py
```

## Execução (Linux)
No terminal, execute:

```py
python3 etapa1.py
# ou
python3 etapa2.py
```
